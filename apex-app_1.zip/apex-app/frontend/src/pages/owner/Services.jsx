export default function Page() {
  return (
    <div className="p-6">
      <h2 className="text-xl font-bold text-gray-900 mb-2">✂️ Services</h2>
      <p className="text-gray-500">Add and manage your services</p>
      <div className="mt-6 bg-white border border-gray-200 rounded-2xl p-8 text-center text-gray-400">
        Under active development
      </div>
    </div>
  )
}
